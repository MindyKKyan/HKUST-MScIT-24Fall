import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

class Perceptron:
    """
    A Perceptron class that represents a single-layer neural network.
    """
    def __init__(self, weights=np.array([0, 0, 0, 0, 0, 0, 0, 0, 0]), bias=0):
        """
        Initialize perceptron with given weights and bias.
        Default weights are zeros, and the bias is zero.
        """
        self.weights = weights  # Weights for the perceptron
        self.bias = bias        # Bias for the perceptron
    
    def predict(self, X):
        """
        Predict function for the perceptron.
        Given input data X, return predictions (1 or 0) based on the current weights and bias.
        """
        linear_combination = np.dot(X, self.weights.T) - self.bias  # Linear combination of weights and inputs
        return list(map(lambda x: 1 if x >= 0 else 0, linear_combination))  # Return 1 if the result is >=0, else 0

class GeneticProgramming:
    """
    A Genetic Programming class that evolves a population of perceptrons
    to find the best perceptron for classification tasks using a training set.
    """
    def __init__(self, X, Y, population_size=1000, copy_rate=0.1, num_candidates=7, 
                 crossover_rate=0.89, mutation_rate=0.01, epochs=10, target_fitness=0.97):
        """
        Initialize the genetic programming parameters.
        X: Feature matrix
        Y: Target labels
        population_size: Number of perceptrons in the population
        copy_rate: Proportion of the population to copy to the next generation
        num_candidates: Number of candidates randomly chosen for selection during copy
        crossover_rate: Proportion of population generated through crossover
        mutation_rate: Proportion of population generated through mutation
        epochs: Maximum number of generations to evolve
        target_fitness: Fitness value threshold to stop the evolution
        """
        self.X = X
        self.Y = Y
        self.population_size = population_size
        self.copy_rate = copy_rate
        self.num_candidates = num_candidates
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.epochs = epochs
        self.target_fitness = target_fitness
        
    def generate_population(self):
        """
        Generate an initial population of perceptrons with random weights and biases.
        """
        self.population = [Perceptron(np.random.randn(9), np.random.random()) for _ in range(self.population_size)]
        
    def compute_fitness(self, predictions):
        """
        Compute the fitness of a perceptron as the accuracy of its predictions.
        """
        return np.sum(self.Y == predictions) / len(self.Y)

    def crossover(self):
        """
        Perform crossover to create new perceptrons by combining weights of two parent perceptrons.
        Randomly selects a crossover point, and the child inherits weights from both parents.
        """
        children = []
        for _ in range(int(self.population_size * self.crossover_rate)):
            parent1, parent2 = np.random.choice(self.population, size=2, replace=False)  # Choose two parents
            weights1, weights2 = np.append(parent1.weights, parent1.bias), np.append(parent2.weights, parent2.bias)
            crossover_point = np.random.randint(1, 9)  # Random crossover point
            child = np.append(weights1[:crossover_point], weights2[crossover_point:])
            children.append(Perceptron(child[:9], child[9]))  # Create child with new weights and bias
        return children

    def copy(self):
        """
        Perform selection and copy the best perceptrons to the next generation.
        Randomly choose a subset of perceptrons and copy the one with the highest fitness.
        """
        copied_perceptrons = []
        for _ in range(int(self.population_size * self.copy_rate)):
            candidates = np.random.choice(self.population, size=self.num_candidates, replace=False)
            fitness_scores = [self.compute_fitness(p.predict(self.X)) for p in candidates]
            copied_perceptrons.append(candidates[fitness_scores.index(max(fitness_scores))])  # Copy the best one
        return copied_perceptrons
    
    def mutate(self):
        """
        Mutate a small part of the population by randomly altering weights.
        Randomly selects a weight in the perceptron and alters its value.
        """
        mutated_perceptrons = []
        for _ in range(int(self.population_size * self.mutation_rate)):
            perceptron = np.random.choice(self.population, size=1)[0]
            weights_with_bias = np.append(perceptron.weights, perceptron.bias)
            mutate_index = np.random.randint(0, 9)  # Random index for mutation
            weights_with_bias[mutate_index] = 1 - weights_with_bias[mutate_index]  # Mutate the weight
            mutated_perceptrons.append(Perceptron(weights_with_bias[:9], weights_with_bias[9]))  # New perceptron
        return mutated_perceptrons
    
    def check_highest_fitness(self):
        """
        Check the fitness of the entire population and return the perceptron with the highest fitness.
        If the fitness of a perceptron meets or exceeds the target fitness, stop the evolution.
        """
        fitness_scores = [self.compute_fitness(p.predict(self.X)) for p in self.population]  # Compute fitness for all
        max_fitness = max(fitness_scores)
        best_perceptron = self.population[fitness_scores.index(max_fitness)]
        return (max_fitness >= self.target_fitness, best_perceptron, max_fitness)
        
    def evolve(self):
        """
        Perform genetic programming evolution to find the best perceptron.
        Evolution continues for a set number of generations or until the target fitness is reached.
        """
        self.generate_population()  # Initialize the population
        
        generation_count = 0
        top_fitness = []
        
        while generation_count < self.epochs:
            # Generate the next generation using copy, crossover, and mutation
            next_generation = self.copy()  
            next_generation.extend(self.crossover())  
            next_generation.extend(self.mutate())  
            
            self.population = next_generation  # Update population with new generation
            
            # Check the fitness of the current population
            evolution_result = self.check_highest_fitness()  
            top_fitness.append(evolution_result[2])  # Append highest fitness for this generation
            
            if evolution_result[0]:  # Stop if the target fitness is reached
                break
            else:
                generation_count += 1
                
        print(f'The highest accuracy is: {evolution_result[2]:.2f}')
    
        # Plot the fitness progress (with red color)
        plt.figure(figsize=[6, 4], dpi=100)
        plt.plot(top_fitness, color='red')
        plt.xlabel('Generation Number')
        plt.ylabel('Top Fitness of the Population')
        plt.title('Top Fitness of Each Generation')
        plt.show()
        
        return evolution_result[1]  # Return the best perceptron

if __name__ == '__main__':
    # Load training data from CSV file
    data = pd.read_csv('assign1-data_python3/gp-training-set.csv', header=None)
    X, Y = np.array(data.loc[:, 0:8]), np.array(data.loc[:, 9]).astype(int)  # Split into features and target labels
    print('X Shape:', X.shape)
    print('Y Shape:', Y.shape)
    np.random.seed(1234)  # Set random seed for reproducibility

    # Define parameters for genetic programming
    population_size = 5000
    copy_rate = 0.09
    num_candidates = 10
    crossover_rate = 0.90
    mutation_rate = 0.01
    epochs = 25
    target_fitness = 1

    # Initialize genetic programming model and evolve the population
    gp_model = GeneticProgramming(X, Y, population_size, copy_rate, num_candidates, crossover_rate, mutation_rate, epochs, target_fitness)
    best_model = gp_model.evolve()

    # Save predictions to CSV
    data.columns = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9', 'Y']
    data['Prediction'] = best_model.predict(X)
    data.to_csv('A1P3_prediction.csv', index=False)
