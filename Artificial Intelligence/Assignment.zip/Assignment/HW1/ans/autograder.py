import os
import subprocess
import time
import psutil
import threading

def run_pacman(layout, agent, time_limit=20):
    command = f"python pacman.py --layout {layout} --pacman {agent} --frameTime 0.01"
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    
    def kill_process():
        parent = psutil.Process(process.pid)
        for child in parent.children(recursive=True):
            child.kill()
        parent.kill()
    
    timer = threading.Timer(time_limit, kill_process)
    try:
        timer.start()
        stdout, stderr = process.communicate()
        if process.returncode != 0:
            return False, stdout
        else:
            return True, stdout
    finally:
        timer.cancel()

def main():
    agents = ["ECAgent", "SMAgent"]
    layouts = [f"evaluateMap{i}" for i in range(4)]

    for agent in agents:
        print(f"--- {agent} ---")
        for layout in layouts:
            print(f"Running on {layout}:")
            success, output = run_pacman(layout, agent)
            if success:
                print(output)
            else:
                print("Failed (exceeded time limit or Pacman died)")
            print()

if __name__ == "__main__":
    main()