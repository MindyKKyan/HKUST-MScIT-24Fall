import pandas as pd
import numpy as np

# Define the Perceptron class
class Perceptron:

    def __init__(self, learning_rate=1):  
        """
        Initialize weights, threshold, and learning rate for the perceptron.
        Weights are initialized to zeros, and the threshold is set to zero.
        """
        self.weights = np.array([0., 0., 0., 0., 0., 0., 0., 0.])  # 8 weights initialized to zero
        self.threshold = 0.  # Initialize threshold to 0
        self.learning_rate = learning_rate  # Set the learning rate (default is 1)
    
    def fit(self, X_train, y_train):
        """
        Train the perceptron using the provided training data.
        The training is repeated until all predictions are correct.
        """
        pred_values = np.dot(X_train, self.weights.T) - self.threshold  # Calculate the predicted values based on weights and threshold
        all_correct = True  # Flag to check if all predictions are correct
        
        for i in range(len(y_train)):  # Loop over each training sample
            predicted_label = 1 if pred_values[i] >= 0 else 0  # Predict label based on threshold

            if predicted_label == y_train[i]:  # If the prediction is correct, move to the next sample
                continue
            else:
                # If prediction is wrong, update weights and threshold
                for k in range(len(self.weights)):
                    self.weights[k] = self.weights[k] + self.learning_rate * (y_train[i] - predicted_label) * X_train[i, k]
                self.threshold = self.threshold - self.learning_rate * (y_train[i] - predicted_label)
                all_correct = False  # Set flag to false since a correction was made
        
        return all_correct  # Return True if all predictions were correct, else False
    
    def predict(self, X_sample):
        """
        Predict the label for a single sample based on the current weights and threshold.
        """
        return 1 if np.dot(X_sample, self.weights.T) + self.threshold >= 0 else 0


# Load the datasets from CSV files
north_data = pd.read_csv('assign1-data_python3/north.csv', header=None)
south_data = pd.read_csv('assign1-data_python3/south.csv', header=None)
west_data = pd.read_csv('assign1-data_python3/west.csv', header=None)
east_data = pd.read_csv('assign1-data_python3/east.csv', header=None)

# Initialize four perceptron models for North, South, West, and East
perceptron_north = Perceptron()
perceptron_south = Perceptron()
perceptron_west = Perceptron()
perceptron_east = Perceptron()

# Train the North perceptron until all predictions are correct
is_all_correct = False
while not is_all_correct:
    X_north, y_north = np.array(north_data.loc[:, 0:7]), np.array(north_data.iloc[:, 8])  # Separate features and labels
    is_all_correct = perceptron_north.fit(X_north, y_north)
print('Weights of North Perceptron:', perceptron_north.weights, ' Threshold:', perceptron_north.threshold)


# Train the South perceptron until all predictions are correct
is_all_correct = False
while not is_all_correct:
    X_south, y_south = np.array(south_data.loc[:, 0:7]), np.array(south_data.iloc[:, 8])
    is_all_correct = perceptron_south.fit(X_south, y_south)
print('Weights of South Perceptron:', perceptron_south.weights, ' Threshold:', perceptron_south.threshold)


# Train the West perceptron until all predictions are correct
is_all_correct = False
while not is_all_correct:
    X_west, y_west = np.array(west_data.loc[:, 0:7]), np.array(west_data.iloc[:, 8])
    is_all_correct = perceptron_west.fit(X_west, y_west)
print('Weights of West Perceptron:', perceptron_west.weights, ' Threshold:', perceptron_west.threshold)


# Train the East perceptron until all predictions are correct
is_all_correct = False
while not is_all_correct:
    X_east, y_east = np.array(east_data.loc[:, 0:7]), np.array(east_data.iloc[:, 8])
    is_all_correct = perceptron_east.fit(X_east, y_east)
print('Weights of East Perceptron:', perceptron_east.weights, ' Threshold:', perceptron_east.threshold)

"""
Weights of North Perceptron: [ 1. -4. -4.  0.  0.  0.  0.  1.]  Threshold: 1.0
Weights of South Perceptron: [ 0.  0.  0.  1.  1. -4. -4.  0.]  Threshold: 1.0
Weights of West Perceptron: [-4.  0.  0.  0.  0.  1.  1. -4.]  Threshold: 1.0
Weights of East Perceptron: [ 0.  1.  1. -4. -4.  0.  0.  0.]  Threshold: 1.0
"""