# reactiveAgents.py
# ---------------
# Licensing Information: You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC
# Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
from game import Directions
from game import Agent
from game import Actions
import util
import time
import search


class NaiveAgent(Agent):
    "An agent that goes West until it can't."

    def getAction(self, state):
        "The agent receives a GameState (defined in pacman.py)."
        sense = state.getPacmanSensor()
        if sense[7]:
            action = Directions.STOP
        else:
            action = Directions.WEST
        return action

class PSAgent(Agent):
    "An agent that follows the boundary using production system."

    def getAction(self, state):
        sense = state.getPacmanSensor()
        x = [sense[1] or sense[2] , sense[3] or sense[4] ,
        sense[5] or sense[6] , sense[7] or sense[0]]
        if x[0] and not x[1]:
            action = Directions.EAST
        elif x[1] and not x[2]:
            action = Directions.SOUTH
        elif x[2] and not x[3]:
            action = Directions.WEST
        elif x[3] and not x[0]:
            action = Directions.NORTH
        else:
            action = Directions.NORTH
        return action

class ECAgent(Agent):
    def getAction(self, state):
        """
        Returns the direction Pacman should move based on sensor inputs and the learned weights.
        """
        # Get the sensor readings and append 1 for the bias
        s = state.getPacmanSensor() + [0.9]  # Sensors: s1 to s8 + threshold (0.9)
        
        # Weights for each direction
        w_north = [1, -2, -2, 0, 0, 0, 0, 1, -0.9]
        w_east = [0, 1, 1, -2, -2, 0, 0, 0, -0.9]
        w_south = [0, 0, 0, 1, 1, -2, -2, 0, -0.9]
        w_west = [-2, 0, 0, 0, 0, 1, 1, -2, -0.9]
        
        # Dot product helper function
        def dot(x, y):
            return sum(i * j for i, j in zip(x, y))
        
        # Decision-making based on sensor input and perceptron weights
        if dot(s, w_north) >= 0:
            return Directions.NORTH
        if dot(s, w_east) >= 0:
            return Directions.EAST
        if dot(s, w_south) >= 0:
            return Directions.SOUTH
        if dot(s, w_west) >= 0:
            return Directions.WEST
        
        # Default action if no direction meets the criteria
        return Directions.NORTH

class SMAgent(Agent):
    "A sensory-impaired agent that follows the boundary using a state machine."

    def registerInitialState(self, state):
        "The agent receives the initial GameState (defined in pacman.py)."
        self.prevAction = Directions.STOP
        self.prevSense = state.getPacmanImpairedSensor()  # Initial sensor inputs from impaired sensors

    def getAction(self, state):
        """
        The agent receives a GameState and returns an action based on the 
        previous action, previous sensory input, and the current sensory input.
        """
        # Get the current impaired sensor readings (north, east, south, west)
        sense = state.getPacmanImpairedSensor()
        prevSense = self.prevSense
        prevAction = self.prevAction
        
        # Initialize action to a default (north) if no decision can be made
        action = Directions.NORTH

        # Define the logic based on the state machine using prevSense and prevAction
        if prevAction == Directions.NORTH:
            if not sense[1]:  # If there's no wall to the east, go east
                action = Directions.EAST
            elif not sense[0]:  # Otherwise, if there's no wall to the north, go north
                action = Directions.NORTH
            else:  # If both are blocked, turn around (go west)
                action = Directions.WEST

        elif prevAction == Directions.EAST:
            if not sense[2]:  # If there's no wall to the south, go south
                action = Directions.SOUTH
            elif not sense[1]:  # Otherwise, if there's no wall to the east, go east
                action = Directions.EAST
            else:  # If both are blocked, turn around (go north)
                action = Directions.NORTH

        elif prevAction == Directions.SOUTH:
            if not sense[3]:  # If there's no wall to the west, go west
                action = Directions.WEST
            elif not sense[2]:  # Otherwise, if there's no wall to the south, go south
                action = Directions.SOUTH
            else:  # If both are blocked, turn around (go east)
                action = Directions.EAST

        elif prevAction == Directions.WEST:
            if not sense[0]:  # If there's no wall to the north, go north
                action = Directions.NORTH
            elif not sense[3]:  # Otherwise, if there's no wall to the west, go west
                action = Directions.WEST
            else:  # If both are blocked, turn around (go south)
                action = Directions.SOUTH

        # Update the previous action and previous sensory inputs
        self.prevAction = action
        self.prevSense = sense

        return action
