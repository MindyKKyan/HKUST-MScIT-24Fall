"""
CSIT 5900 AI 
Homework 3 Programming Part: Lady.py
Nov 25 2024
21108128
Mingzhen JIANG
"""

from z3 import *

# Define Boolean variables for each room
# l1, l2, l3 indicate whether a lady is in Room 1, 2, or 3 respectively
l1, l2, l3 = Bools('l1 l2 l3')

# Create a solver instance
s = Solver()

# Constraint 1: Exactly one room contains a lady
s.add(Or(
    And(l1, Not(l2), Not(l3)),  # Lady in Room 1 only
    And(Not(l1), l2, Not(l3)),  # Lady in Room 2 only
    And(Not(l1), Not(l2), l3)   # Lady in Room 3 only
))

# Sign predicates for each room
# p1, p2, p3 represent the truth of signs for Room 1, Room 2, and Room 3 respectively
p1 = Not(l1)  # The sign on Room 1 reads "There is no lady in Room 1"
p2 = l2       # The sign on Room 2 reads "There is a lady in Room 2"
p3 = Not(l2)  # The sign on Room 3 reads "There is no lady in Room 2"

# Constraint 2: At most one of the signs can be true
s.add(Or(
    And(Not(p1), Not(p2), Not(p3)),  # No signs are true
    And(Not(p1), Not(p2), p3),       # Only Room 3's sign is true
    And(Not(p1), p2, Not(p3)),       # Only Room 2's sign is true
    And(p1, Not(p2), Not(p3))        # Only Room 1's sign is true
))

# Solve the constraints
print("Initial Check:", s.check())  # Check satisfiability
print("Model:", s.model())  # Output the solution (expected: l1=True, l2=False, l3=False)

# Additional Test: Add a negation constraint
# If we assume that there is no lady in Room 1
s.add(Not(l1))

# Re-check satisfiability after adding the negation constraint
print("After Adding Not(l1):", s.check())  # Expected: unsat
