"""
CSIT 5900 AI 
Homework 3 Programming Part: Ranking.py
Nov 25 2024
21108128
Mingzhen JIANG
"""

from z3 import *

# Define Boolean variables for ranking
l1, l2, l3, l4 = Bools('Lisa_Rank_1 Lisa_Rank_2 Lisa_Rank_3 Lisa_Rank_4')
b1, b2, b3, b4 = Bools('Bob_Rank_1 Bob_Rank_2 Bob_Rank_3 Bob_Rank_4')
j1, j2, j3, j4 = Bools('Jim_Rank_1 Jim_Rank_2 Jim_Rank_3 Jim_Rank_4')
m1, m2, m3, m4 = Bools('Mary_Rank_1 Mary_Rank_2 Mary_Rank_3 Mary_Rank_4')

# Define additional Boolean variables for majors
lm, mm = Bools('Lisa_Biology_Major Mary_Biology_Major')

# Create a solver instance
s = Solver()

# Constraints for rankings
# Each person has exactly one rank
for person in [[l1, l2, l3, l4], [b1, b2, b3, b4], [j1, j2, j3, j4], [m1, m2, m3, m4]]:
    s.add(Sum([If(rank, 1, 0) for rank in person]) == 1)

# Each rank is assigned to exactly one person
for rank in zip([l1, b1, j1, m1], [l2, b2, j2, m2], [l3, b3, j3, m3], [l4, b4, j4, m4]):
    s.add(Sum([If(pos, 1, 0) for pos in rank]) == 1)

# Fact 1: Lisa and Bob cannot be consecutive in the ranking
s.add(Not(And(l1, b2)), Not(And(b1, l2)), Not(And(l2, b3)), Not(And(b2, l3)), 
      Not(And(l3, b4)), Not(And(b3, l4)))

# Fact 2: Biology major relationships
s.add(Implies(lm, Or(And(j1, l2), And(j2, l3), And(j3, l4))))
s.add(Implies(mm, Or(And(j1, m2), And(j2, m3), And(j3, m4))))

# Fact 3: Bob and Jim must be consecutive
s.add(Or(And(b1, j2), And(b2, j3), And(b3, j4)))

# Fact 4: Either Lisa or Mary is a biology major, but not both
s.add(Or(And(lm, Not(mm)), And(Not(lm), mm)))

# Fact 5: Either Lisa or Mary ranks first
s.add(Or(l1, m1))

# Solve the problem
if s.check() == sat:
    model = s.model()
    print("Solution:")
    for var in model.decls():
        if model[var]:
            print(f"{var.name()} = True")
else:
    print("No solution found.")

# The ranking order: (Mary, Bob, Jim, Lisa).