# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    # 初始化栈、已访问集合和起始节点
    stack = util.Stack()
    visited = set()
    startState = problem.getStartState()
    stack.push((startState, []))  # (状态, 动作列表)

    while not stack.isEmpty():
        currentState, actions = stack.pop()

        if problem.isGoalState(currentState):
            return actions

        if currentState not in visited:
            visited.add(currentState)

            for nextState, action, cost in problem.getSuccessors(currentState):
                if nextState not in visited:
                    newActions = actions + [action]
                    stack.push((nextState, newActions))

    return []  # 如果没有找到路径

def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    
    # initialize the search tree using the initial state of problem
    queue = util.Queue()
    queue.push((problem.getStartState(), []))
    visited = []

    while not queue.isEmpty():
        # choose a leaf node for expansion
        state, actions = queue.pop()

        # if the node contains a goal state then return the corresponding solution
        if problem.isGoalState(state):
            return actions

        # expand the node and add the resulting nodes to the search tree
        if state not in visited:
            visited.append(state)
            for successor, action, stepCost in problem.getSuccessors(state):
                if successor not in visited:
                    queue.push((successor, actions + [action]))
    return False

def uniformCostSearch(problem):
     """Search the node of least total cost first."""
     """*** YOUR CODE HERE ***"""
     # 初始化优先队列、已访问集合和起始节点
     pq = util.PriorityQueue()
     visited = set()
     startState = problem.getStartState()
     pq.push((startState, [], 0), 0)  # (状态, 动作列表, 总成本)

     while not pq.isEmpty():
         currentState, actions, currentCost = pq.pop()

         if problem.isGoalState(currentState):
             return actions

         if currentState not in visited:
             visited.add(currentState)

             for nextState, action, stepCost in problem.getSuccessors(currentState):
                 if nextState not in visited:
                        newActions = actions + [action]
                        newCost = currentCost + stepCost
                        pq.push((nextState, newActions, newCost), newCost)

     return []  # 如果没有找到路径

def nullHeuristic(state, problem=None):
    """
    一个启发式函数估计从当前状态到最近目标的成本
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
     # 初始化起始节点
    startState = problem.getStartState()
    startNode = (startState, [], 0)  # (状态, 动作列表, 成本)
    
    # 使用优先队列来存储待探索的节点
    frontier = util.PriorityQueue()
    frontier.push(startNode, heuristic(startState, problem))
    
    # 用于存储已探索的状态
    explored = set()
    while not frontier.isEmpty():
        # 选择并移除具有最低f(n)值的节点
        currentState, actions, currentCost = frontier.pop()
        
        # 如果当前状态是目标状态，返回动作列表
        if problem.isGoalState(currentState):
            return actions
        
        # 如果当前状态未被探索过，则进行探索
        if currentState not in explored:
            explored.add(currentState)
            
            # 获取并检查所有后继状态
            for nextState, action, stepCost in problem.getSuccessors(currentState):
                if nextState not in explored:
                    newActions = actions + [action]
                    newCost = currentCost + stepCost
                    newNode = (nextState, newActions, newCost)
                    # 计算f(n) = g(n) + h(n)
                    priority = newCost + heuristic(nextState, problem)
                    frontier.push(newNode, priority)
    
    # 如果没有找到路径，返回空列表
    return []


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
